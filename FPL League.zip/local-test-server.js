const express = require('express');
const cors = require('cors');
const fetch = require('node-fetch');
const path = require('path');

const app = express();
const PORT = 3001; // Different from your React projects

// Enable CORS
app.use(cors());

// Serve static files
app.use(express.static('.'));

// FPL API proxy endpoint
app.get('/api/fpl-proxy', async (req, res) => {
    const { league_id } = req.query;
    
    if (!league_id) {
        return res.status(400).json({ error: 'League ID is required' });
    }
    
    if (!league_id.match(/^\d+$/)) {
        return res.status(400).json({ error: 'Invalid League ID' });
    }
    
    try {
        const fplUrl = `https://fantasy.premierleague.com/api/leagues-classic/${league_id}/standings/`;
        
        const response = await fetch(fplUrl, {
            headers: {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
            }
        });
        
        if (!response.ok) {
            return res.status(response.status).json({ 
                error: `FPL API returned HTTP ${response.status}` 
            });
        }
        
        const data = await response.json();
        res.json(data);
        
    } catch (error) {
        console.error('Error fetching FPL data:', error);
        res.status(500).json({ 
            error: 'Failed to fetch data from FPL API' 
        });
    }
});

// Serve the main page
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'fpl-league.html'));
});

app.listen(PORT, () => {
    console.log(`FPL Test Server running on http://localhost:${PORT}`);
    console.log('Press Ctrl+C to stop the server');
}); 